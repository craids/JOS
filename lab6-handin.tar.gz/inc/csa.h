int csa; 
#define ETEMPREGION 0xe0000000

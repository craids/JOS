echo hello world | cat
cat lorem
cat lorem |num
cat lorem |num |num |num |num |num
lsfd -1
cat script
sh <script
